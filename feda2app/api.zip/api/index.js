// server.js
const dotenv = require('dotenv');
dotenv.config();

const allowedExt = [
  '.js',
  '.ico',
  '.css',
  '.png',
  '.jpg',
  '.woff2',
  '.woff',
  '.ttf',
  '.svg',
];

const express = require('express'),
  path = require('path'),
  bodyParser = require('body-parser'),
  cors = require('cors'),
  mongoose = require('mongoose');

const secure = require('./routes/securing.route');

mongoose.Promise = global.Promise;
mongoose.connect(process.env.MDBCS, {
  useNewUrlParser: true
}).then(
  () => {
    console.log('Database is connected')
    mongoose.set('useFindAndModify', false);
  },
  err => { console.log('Can not connect to the database'+ err)}
);

const app = express();
app.use(express.static(process.env.ANGAPPDIRNAME));
app.use(bodyParser.json());
app.use(cors());

//ROUTES ------------------------------------------------
// Gen CRUD
const genCrudRoute = require('./routes/gencrud.route');
app.use('/api/gencrud', genCrudRoute);

// Usuarios
const usersRoute = require('./routes/user.route');
app.use('/api/users', secure.checkToken, usersRoute);

// Clients
const clientsRoute = require('./routes/clients.route');
app.use('/api/clients', secure.checkToken, clientsRoute);

// Auth
const authRoute = require('./routes/auth.route');
app.use('/api/auth', authRoute);

// //Instituciones
// const instRoute = require('./route/instituciones.route');
// app.use('/api/instituciones', instRoute);
// //Conferencias
// const conferenciaRoute = require('./route/conferencias.route');
// app.use('/api/conferencias', conferenciaRoute);
// //Documentos
// const docsRoute = require('./route/docs.route');
// app.use('/api/docs', docsRoute);
// //DocEtiquetas
// const docEtq = require('./route/docetiquetas.route');
// app.use('/api/docetiq', docEtq);
// //Usuarios
// const userRoute = require('./route/usuarios.route');
// app.use('/api/usuarios', userRoute);



const port = process.env.PORT || 4350;

const server = app.listen(port, function(){
  console.log('Listening on port ' + port);
});
