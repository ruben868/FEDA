
const commonService = {

  hasIdProperty: function () {

  }
};
