// USUARIOS

const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const DocInfo = require('../models/docinfo.model');
const AuthUser = require('../models/auth-user.model');

// Define collection and schema for Business
let Usuario = new Schema({
  authUserId: {type: Schema.ObjectId},
  authInfo: { type: AuthUser.schema },
  org: {
    nom: {type: String},
    area: {
      nom: {type: String},
    }
  },
  entFed: {
    cve: {type: String},
    nom: {type: String},
  },
  roles: [{
    cve: {type: String},
    nom: {type: String},
  }],
  docInfo: { type: DocInfo.schema }
});

module.exports = mongoose.model('usuarios', Usuario);
