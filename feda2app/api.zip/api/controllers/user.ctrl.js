
// Common = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =
const _ = require('lodash');
const request = require("request-promise");
const querystring = require('query-string');
const dotenv = require('pwd');
dotenv.config();

// DB & Models = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =


module.exports = {
  getUserById: getUserById,
};

async function getUserById (authIdUser, authInfo) {
  // Obtener información del servidor

}


async function getAuthUserData(idUser, authInfo) {
  let authUserData = null;
  const headers = {
    'Authorization': 'Bearer ' + _.get(authInfo, 'token', ''),
    'x-int-cid': _.get(authInfo, 'clientId', ''),
    'x-int-aid': _.get(authInfo, 'userId', ''),
  };
  const url = dotenv.AUTH_API_URL + 'users/getById/' + authInfo.client;

  const data = {
    headers: headers,
    url:     url,
    body:    querystring.stringify(paramData),
  };

  try {
    authUserData  = await request.post(data);
  } catch (e) {
    // ERROR
  }

  return authUserData;
}
