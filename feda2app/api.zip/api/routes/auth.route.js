const express = require('express');
const mongoose = require('mongoose');
const router = express.Router();
const _ = require('lodash');
const crypto = require('crypto');
let AuthCodeInfo = require('../models/auth-code-info.model');
let User = require('../models/usuario.model');
const moment = require('moment');
let AuthToken = require('../models/auth-token.model');
const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');
dotenv.config();
const jwt_secret = process.env.JWTSECRET;
let Clients = require('../models/clients.model');
let AuthData = require('../models/auth-data.model');

const authCodeExpiration = 3;
const tokenMinExpiration = 1;
const jwtExpirationMinutes = 1;
const defaultTokenExpirationMinutes = 1440;

const jwtRenewTimeInMinutes      = 5;
const jwtExpirationTimeInMinutes = 24*60;


router.route('/v1/getAuthCode').post(function (req, res) {
  let fnMain = async (req,res) => {
    try {
      let response = await createAuthCode(req.body.auth, req.body.userData);
      console.log(response);
      res.status(200).send({
        authCode: response.authCode.authCodeHash
      });
    } catch (error){
      console.log(error);
      res.status(400).send(error);
    }
  };

  fnMain(req, res);
});

router.route('/v1/getToken').post(function (req, res) {
  let fnMain = async (req,res) => {
    try {
      const data = req.body;
      let response = await getToken(data.authcode, data.clientId, data.code);
      res.status(200).send({
        token: response.token.jwt,
        rt: response.refreshToken,
        ui: response.userInfo
      });
    } catch (error) {
      if (error.message.indexOf('ExpiredAuthToken')!== -1) {
        res.status(401).send(error);
        return;
      }

      console.log(error.message);
      res.status(400).send(error);
    }
  };

  fnMain(req, res);
});

router.route('/v1/checkToken').post(function (req, res) {
  let fnMain = async (req,res) => {
    try {
      const data = req.body;
      let response = await checkToken(data);
      res.status(200).send(response);
    } catch (error){
      console.log(error);
      if (error.message.indexOf('InvalidToken')!== -1) {
        console.log('checkToken (1)');
        res.status(401).json(error);
        return;
      }

      res.status(400).send(error);
    }
  };

  fnMain(req, res);
});

router.route('/v1/checkTokenCli').post(function (req, res) {
  let fnMain = async (req,res) => {
    try {
      console.log('checkTokenCli (1)');
      const data = req.body;
      let response = await clientCheckToken(data.clientId, data.token);
      console.log('checkTokenCli (2)');
      console.log(response);


      if (response) {
        console.log('checkTokenCli (3)');
        res.status(200).json({
          itv: response
        });
      } else {
        console.log('checkTokenCli (4)');
        throw new Error('UnknowError');
      }
    } catch (error){
      console.log('checkTokenCli (5)');
      if (error.message.indexOf('InvalidToken')!== -1) {
        console.log('checkTokenCli (6)');
        res.status(401).send(error);
        return;
      }
      console.log('checkTokenCli (7)');
      res.status(400).send(error);
      return;
    }
  };

  fnMain(req, res).catch(function(error, data){
    console.log('checkTokenCli (2.1)');
    console.log(error);
    console.log(data);
    res.status(400).send(error);
  });
});

router.route('/v1/renewToken').post(function (req, res) {
  console.log('/v1/renewToken (1)');
  let fnMain = async (req,res) => {
    try {
      const data = req.body;
      // authCode, clientCode, clientId
      let response = await refreshToken(data.rt, data.cv);
      res.status(200).json({
        token: response
      });
    } catch (error) {
      if (error.message.indexOf('ExpiredClientCode')!== -1) {
        res.status(401).send(error);
        return;
      }
      // Error desconocido
      console.log(error);
      res.status(400).send(error);
    }
  };

  fnMain(req, res);
});

router.route('/v1/logout').post(function (req, res) {
  let fnMain = async (req,res) => {
    try {
      const data = req.body;
      // authCode, clientCode, clientId
      let response = await refreshToken(data.clientId, data.token);
      res.status(200).send(response);
    } catch (error) {
      // Error desconocido
      console.log(error);
      res.status(400).send(error);
    }
  };

  fnMain(req, res);
});

router.route('/v1/getClientName').post(function (req, res) {
  let fnMain = async (req,res) => {
    try {
      const data = req.body;
      let response = await getClientName(data.clientId);

      if (!_.isNil(response)) {
        console.log(response);
        res.status(200).json(response);
      } else {
        console.log('error');
        res.status(400).json(response);
      }
    } catch (error) {
      // Error desconocido
      console.log(error);
      res.status(400).json(error);
    }
  };

  fnMain(req, res);
});

async function getClientName (clientId) {
  console.log('getClientName (1)');
  console.log(clientId);
  // Obtener la información
  const dbSearch = await Clients.findOne({'clientId': clientId});

  console.log('getClientName (2)');
  console.log(dbSearch);

  if (_.isNil(dbSearch)) {
    return null;
  } else {
    return {
      clientName: dbSearch.clientName
    };
  }
}

async function logout (clientId, token) {
  // Obtener la información
  const dbSearch = await AuthData.findOne({'token.jwt': token, 'client.clientId': clientId});

  if (!_.isNil(token)) {
    dbSearch.isActive = false;
    await dbSearch.save();
    return true;
  } else {
    return false;
  }

  return false;
}

async function createAuthCode (data, userData) {
  // TODO: Validar que el client id exista

  // Validar credenciales
  let authData = null;
  const user = await authenticate(userData);
  console.log(user);

  if(!_.isNil(user)) {
    // Generar auth code
    const authCodeCreated = generateAuthCode(null);
    const sesion = await newSesionToken(data.clientId, user.id, null, true);
    /*
      sesionObj = {
    clientId: clientId,
    userId: userId,
    sesionId: sesionId,
    creation: creationDate,
    keepSesion: keepSesion
  };

  const jwtToken = jwt.sign(sesionObj, jwt_secret);

  return {
    token: jwtToken,
    sesionObj: sesionObj
  };
     */

    authData = new AuthData({
      client: {
        clientId: data.clientId,
      },
      requestInfo: {
        responseType: data.responseType,
        scope: data.scope,
        redirectUrl: data.redirectUrl
      },
      authCode: {
        created: authCodeCreated.creationDate,
        authCodeHash: authCodeCreated.authCode,
        expirationTime: authCodeCreated.expirationTime
      },
      userInfo: {
        id: user._id,
        mail: user.mail,
        nom: user.nom,
        appat: user.appat,
        apmat: user.apmat
      },
      pkce: {
        codeChallange: data.codeChallange,
        codeChallangeMethod: data.codeChallangeMethod
      },
      sesion: {
        id: sesion.sesionObj.sesionId,
        token: sesion.token,
        isActive: true
      },
      isActive: true
    });

    console.log(authData);

    await authData.save();
  } else {
    throw new Error('UserOrPwdIncorrect');
    return;
  }

  return authData;
}

async function authenticate (userData) {
  const hpwd = crypto.createHash('sha256').update(userData.pwd).digest('base64');

  let response = await User.findOne({mail: userData.mail, hpwd: hpwd});

  console.log(response);

  return response;
}

function makeid(length) {
  let result           = '';
  let characters       = '@ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-!';
  let charactersLength = characters.length;
  for ( let i = 0; i < length; i++ ) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}

function dynamicHashMethod() {
  let methods = ['sha1', 'sha256', 'sha512'];
  let result           = Math.floor(Math.random() * 3);
  console.log(result);
  console.log(methods[result]);
  return methods[result];
}

async function getToken(authCode, clientId, codeVerifier) {
  console.log('getToken (1)');
  // console.log(data);

  // Validar codigo de autorizacion --------------------------------------------------------
  console.log('getToken (2)');
  console.log(authCode);
  console.log(clientId);
  console.log(codeVerifier);
  let authData = await AuthData.findOne({'authCode.authCodeHash': authCode, 'client.clientId': clientId});

  if (_.isNil(authData)) {
    console.log('Auth Data is null...');
    throw new Error('InvalidAuthCode');
    return;
  }

  // Validar vigencia del codigo de autorizacion -------------------------------------------
  console.log('getToken (3)');
  if (hasExpired(authData.authCode.created, authData.authCode.expirationTime)) {
    throw new Error('ExpiredAuthToken');
  }

  // TODO: Validar client id ---------------------------------------------------------------
  console.log('getToken (4)');
  let clientCodeValidation = await validateClientCode(authData, codeVerifier);
  console.log(clientCodeValidation);
  if (!clientCodeValidation.isValid || clientCodeValidation.hasExpired) {
    console.log('getToken (4) Error');
    throw new Error('InvalidAuthCode');
  }

  // Validar la sesion
  console.log('getToken (5)');
  if (!isSesionValid(authData)) {
    throw new Error('InvalidAuthCode');
  }

  // Generar token -------------------------------------------------------------------------
  console.log('getToken (5)');
  const tokenGenerated = generateToken(authData.client.clientId, authData.userInfo);

  authData.token = {
    jwt: tokenGenerated.token,
    creation: tokenGenerated.creationDate,
    expirationTime: tokenGenerated.expirationTime,
    userInfo: authData.userInfo
  };

  // Generar refreshToken -------------------------------------------------------------------------
  const refreshToken = await newRefreshToken(authData.client.clientId, authData.userInfo.id, authData.sesion.id, true, null);
  authData.refreshToken = refreshToken;
  console.log('getToken (6)');
  console.log(authData.refreshToken);

  authData = await authData.save();

  console.log(authData);
  console.log('getToken <<<<<<<<<<<');

  return authData;
}

// async function getToken(data) {
//   console.log('getToken (1)');
//   console.log(data);
//
//   // Validar codigo de autorizacion --------------------------------------------------------
//   console.log('getToken (2)');
//   let authData = await AuthData.findOne({'authCode.authCodeHash': data.authcode});
//
//   if (_.isNil(authData)) {
//     console.log('Auth Data is null...');
//     throw new Error('InvalidAuthCode');
//     return;
//   }
//
//   // Validar vigencia del codigo de autorizacion -------------------------------------------
//   console.log('getToken (3)');
//   if (hasExpired(authData.authCode.created, authData.authCode.expirationTime)) {
//     throw new Error('ExpiredAuthToken');
//   }
//
//   // TODO: Validar client id ---------------------------------------------------------------
//   console.log('getToken (4)');
//   let clientCodeValidation = validateClientCode(authData, data.code);
//   if (clientCodeValidation.isValid && !clientCodeValidation.hasExpired) {
//     throw new Error('InvalidAuthCode');
//   }
//
//   // Generar token -------------------------------------------------------------------------
//   console.log('getToken (5)');
//   const tokenGenerated = generateToken(authData.client.clientId, authData.userInfo);
//
//   authData.token = {
//     jwt: tokenGenerated.token,
//     creation: tokenGenerated.creationDate,
//     expirationTime: tokenGenerated.expirationTime
//   };
//
//   // poner datos de la sesion
//   authData.sesion = {
//     isActive: true,
//     createdDate: tokenGenerated.creationDate,
//     logoutDate: null
//   };
//
//   authData = await authData.save();
//
//   console.log(authData);
//   console.log('getToken <<<<<<<<<<<');
//
//   return authData;
// }

async function checkToken(data) {
  //let response = false;
  console.log('checkToken >>>>>>>>>>');
  console.log(data);
  const clientId  = data.clientId;
  const jwtToken     = data.token;
  const clientSecret = data.clientSecret;

  // Validar cliente -----------------------------------------------------------------------
  const checkClientSecretResp = await checkClientSecret(clientId, clientSecret);
  if (!checkClientSecretResp) {
    console.log('Client id and client secret are invalid');
    throw new Error('InvalidToken');
    return;
  }

  const dbSearch = await AuthData.findOne({'token.jwt': jwtToken, 'client.clientId': clientId});
  if (_.isNil(dbSearch)) {
    console.log('No se encontró en db por el criterio token, clientId');
    throw new Error('InvalidToken');
  }

  if (!isTokenValid(jwtToken, dbSearch)) {
    throw new Error('InvalidToken');
  }

  console.log('checkToken <<<<<<<<<<<<');
  return data;
}

async function clientCheckToken(clientId, token) {
  let returnVal = false;
  console.log('clientCheckToken (1)');

  // Validar cliente -----------------------------------------------------------------------
  const dbSearch = await AuthData.findOne({'token.jwt': token, 'client.clientId': clientId});

  if (_.isNil(dbSearch)) {
    console.log('clientCheckToken (2): Error; dbSearch is null');
    throw new Error('InvalidToken');
    return;
  }

  console.log('clientCheckToken (3)');
  if (!isTokenValid(token,dbSearch)) {
    console.log('clientCheckToken (4): Error; token invalid!');
    throw new Error('InvalidToken');
  } else {
    console.log('clientCheckToken (5)');
    returnVal = true;
  }
  console.log('clientCheckToken (6)');

  return returnVal;
}

async function checkTokens(token, refreshToken) {
  let returnVal = {
    t: false,
    rt: false
  };

  console.log('checkTokens (1)');

  // Validar cliente -----------------------------------------------------------------------
  const dbSearch = await AuthData.findOne({'token.jwt': token, 'refreshToken': refreshToken});

  if (!_.isNil(dbSearch)) {
    console.log('checkTokens (2)');

    if (isTokenValid(token, dbSearch)) {
      returnVal.t = true;
    }
  }

  return returnVal;
}

async function newRefreshToken(clientId, userId, sesionId, keepSesion, creationDate) {
  // Se asume que estos elementos ya fueron validados.
  // GENERATE JWT TOKEN
  console.log('newRefreshToken (1)');
  if (_.isNil(clientId) || _.isNil(userId) || _.isNil(sesionId)) {
    console.log('newRefreshToken (2)');
    return null;
  }


  console.log('newRefreshToken (3)');
  creationDate = _.isNil(creationDate) ? new Date() : creationDate;

  const expirationInMinutes = 7200;
  const jwtToken = jwt.sign({
    clientId: clientId,
    userId: userId,
    sesionId: sesionId,
    creation: creationDate,
    expiration: expirationInMinutes,
    keepSesion: keepSesion
  }, jwt_secret);

  return jwtToken;
}

async function newSesionToken(clientId, userId, creationDate, keepSesion) {
  console.log('newSesionToken (1)');
  // Se asume que estos elementos ya fueron validados.
  // GENERATE JWT TOKEN
  if (_.isNil(clientId) || _.isNil(userId)) {
    console.log('newSesionToken (2)');
    console.log(clientId);
    console.log(userId);
    return null;
  }

  console.log('newSesionToken (3)');
  const algo = dynamicHashMethod();
  const tokenCore = makeid(50) + '-' + moment().format('YYYYMMDDHHmmssSSS');
  const sesionId = crypto.createHash('sha256').update(tokenCore).digest('base64');

  creationDate = _.isNil(creationDate) ? new Date() : creationDate;
  keepSesion = _.isNil(keepSesion) ? false : keepSesion;

  sesionObj = {
    clientId: clientId,
    userId: userId,
    sesionId: sesionId,
    creation: creationDate,
    keepSesion: keepSesion
  };

  const jwtToken = jwt.sign(sesionObj, jwt_secret);

  return {
    token: jwtToken,
    sesionObj: sesionObj
  };
}

async function refreshToken(refreshToken, codeVerifier) {
  // Buscar en db
  console.log('refreshToken (1)');
  let returnVal = null;
  let dbSearch = await AuthData.findOne({'refreshToken': refreshToken });

  if (!_.isNil(dbSearch)) {
    console.log('refreshToken (2)');
    // Validaciones
    let isValid = true;

    // Validar codeVerifier ---------------------------------------------------------------
    let clientCodeValidation = await validateClientCode(dbSearch, codeVerifier);
    if (!clientCodeValidation.isValid || clientCodeValidation.hasExpired) {
      isValid = false;
      console.log('refreshToken (3)');
      console.log(clientCodeValidation);
    }

    // Validar sesion
    if (!isSesionValid(dbSearch)) {
      console.log('refreshToken (4)');
      console.log(dbSearch);
      isValid = false;
    }

    // Validar refershToken
    console.log(dbSearch.client.clientId.toString());
    const decodedJwt = jwt.verify(refreshToken, jwt_secret);
    if (
      decodedJwt.clientId !== dbSearch.client.clientId ||
      decodedJwt.userId !== dbSearch.userInfo.id.toString() ||
      hasExpired(decodedJwt.creationDate, decodedJwt.expiration)
    ) {
      isValid = false;
      console.log('refreshToken (5)');
      console.log(decodedJwt);
      console.log(dbSearch);
    }

    // ha pasado todas las validaciones
    if (isValid) {
      console.log('refreshToken (6)');
      // generar nuevo token
      const tokenGenerated = generateToken(dbSearch.client.clientId, dbSearch.userInfo);
      dbSearch.token = {
        jwt: tokenGenerated.token,
        creation: tokenGenerated.creationDate,
        expirationTime: tokenGenerated.expirationTime
      };
      dbSearch = await dbSearch.save();

      returnVal = tokenGenerated.token;
    }
  }

  console.log('refreshToken (4)');
  console.log(returnVal);
  return returnVal;
}

async function checkClientSecret(clientId, clientSecret) {
  let response = false;
  const dbSearch = await Clients.findOne({clientId: clientId, clientSecret: clientSecret});
  console.log(dbSearch);

  if (!_.isNil(dbSearch)) {
    response = true;
  }

  return response;
}

async function validateClientCode(dbAuthData, clientCode) {
  let response = false;
  let vHasExpired = false;
  let dbSearch = null;

  console.log('validateClientCode (1)');

  try {
    const clientSecret = crypto.createHash(dbAuthData.pkce.codeChallangeMethod).update(clientCode).digest('base64');
    console.log(clientSecret);

    if (dbAuthData.pkce.codeChallange === clientSecret) {
      console.log('validateClientCode (2)');
      response = true;

      //vHasExpired = hasExpired(dbAuthData.pkce.creationDate, dbAuthData.pkce.expirationTime);
      vHasExpired = false;
    } else {
      console.log('validateClientCode (2): else');
      console.log(dbAuthData.pkce.codeChallange)
    }

  } catch (error) {
    console.log('validateClientCode (3)');
    console.log(error);
  }

  return {
    isValid: response,
    hasExpired: vHasExpired,
    data: dbSearch
  };
}

function generateAuthCode (creationDate) {
  const tempCode = makeid(60) + moment().format('YYYYMMDDHHmmssSSS');
  const algo = dynamicHashMethod();
  const authCodeHash = crypto.createHash(algo).update(tempCode).digest('base64');

  return {
    authCode: authCodeHash,
    method: algo,
    creationDate: creationDate || new Date(),
    expirationTime: authCodeExpiration
  };
}

function generateToken (clientId, userInfo) {
  const algo = dynamicHashMethod();
  const tokenCore = makeid(50) + moment().format('YYYYMMDDHHmmssSSS');
  console.log(tokenCore);
  const token = crypto.createHash(algo).update(tokenCore).digest('base64');
  console.log(token);
  const currentDate = new Date();

  // GENERATE JWT TOKEN
  const jwtToken = jwt.sign({
    clientId: clientId,
    token: token,
    user: userInfo,
    creation: currentDate,
    expiration: jwtExpirationMinutes
  }, jwt_secret);

  return {
    token: jwtToken,
    creationDate: currentDate,
    expirationTime: jwtExpirationMinutes
  };
}

function isSesionValid(dbData) {
  let returnVal = false;

  if (dbData.sesion.isActive) {
    returnVal = true;
    // let decodedSesion = null;
    //
    // try {
    //   decodedSesion = jwt.verify(sesionToken, jwt_secret);
    // } catch (e) {
    //   returnVal = false;
    // }
    //
    // if (!_.isNil(decodedSesion)) {
    //   if (
    //     decodedSesion.clientId === dbData.client.clientId &&
    //     decodedSesion.sesionId === dbData.sesion.id &&
    //     decodedSesion.userId === dbData.userInfo.id
    //   ) {
    //     returnVal = true;
    //   }
    // }
  }

  return returnVal;
}

function isTokenValid(token, dbData) {
  /*
  clientId: clientId,
    token: token,
    user: userInfo,
    creation: currentDate,
    expiration: jwtExpirationMinutes
   */
  console.log('isTokenValid (1)');
  let returnVal = false;
  const decodedJwt = jwt.verify(token, jwt_secret);
  console.log('isTokenValid (2)');
  // Validar congruencia con bd
  console.log(decodedJwt);
  console.log(moment(decodedJwt.creation).toDate());
  console.log(dbData);
  if ( moment(decodedJwt.creation).isSame(dbData.token.creation)) {
    console.log('isTokenValid (3)');
    if (!hasExpired(decodedJwt.creation, decodedJwt.expiration)) {
      console.log('isTokenValid (4)');
      returnVal = true;
    }
  }

  console.log('isTokenValid (5)');
  return returnVal;
}
// 2019-11-04T02:52:30.848Z,

// async function checkClientCode(clientId, clientCode, algo) {
//   let response = false;
//   let vHasExpired = false;
//   let dbSearch = null;
//
//   try {
//     const clientSecret = crypto.createHash(algo).update(clientCode).digest('base64');
//     dbSearch = await Clients.findOne({clientId: clientId, clientSecret: clientSecret});
//     console.log(dbSearch);
//
//     if (!_.isNil(dbSearch)) {
//       response = true;
//
//       vHasExpired = hasExpired(dbSearch.pkce.creationDate, dbSearch.pkce.expirationTime);
//     }
//
//   } catch (error) {
//     console.log(error);
//   }
//
//   return {
//     isFound: response,
//     hasExpired: vHasExpired,
//     data: dbSearch
//   };
// }

function hasExpired(date, expirationTimeInMinutes) {
  let returnVal = true;
  const diffInMin = moment(new Date()).diff(date, 'minutes');
  if (diffInMin > expirationTimeInMinutes) {
    // Token ha expirado
    console.log('La fecha ha expirado');
  } else {
    returnVal = false;
  }
  return returnVal;
}

module.exports = router;

